import Data.Array

numeradores:: Integer -> Double -> Array Integer Double
numeradores n x = array (1, n) [(i,x^i)| i <- [1..n]]

fatorial:: Integer -> Integer
fatorial n
  | n == 0 = 1
  | otherwise = n * fatorial(n-1)

serieTaylor:: Integer -> Double -> Double
serieTaylor n x = 1 + (foldr1 (+) [(((numeradores n x)!a)) / (fromIntegral (fatorial a)) | a <- [1..n]])

mat:: Array (Int,Int) Int

mat = array ((1,1),(2,2)) [((1,1),2),((1,2),2),((2,1),3),((2,2),4)]

matrizTransposta :: Array (Int,Int) Int -> Array (Int,Int) Int

matrizTransposta a = array ((li,ui), (lj,uj)) [((i,j),a!(j,i)) | i <- [li..lj], j <- [ui..uj]] where ((li,ui), (lj,uj)) = bounds a
