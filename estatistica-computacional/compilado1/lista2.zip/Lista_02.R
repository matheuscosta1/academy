# Alunos: Kemuel Santos Peres - 11811BCC035
#	  Pedro Henrique Resende Ribeiro - 12011BCC004

Questão 01

# Letra A

vetor_1A <- 1:10

# Letra B

vetor_1B <- 20:1

# Letra C

vetor_1C <- c(seq(from = 1, to = 20, by = 1), seq(from = 19, to = 1, by = -1))

# Letra D

exp1 <- seq(from = 3, to = 36, by = 3)
exp2 <- seq(from = 1, to = 34, by = 3)

tamanho <- length(exp1)
vet_1D <- c( )

for(i in 1:tamanho){ 
  vet_1D[i] <- (0.1 ** exp1[i]) * (0.2 ** exp2[i])
}


# Letra E

vet_1E <- rep(c(4,6,3), each = 1, times = 10)

# Letra F

vet_1F <- rep(c(4,6,3), each = 1, len = 31)

Questão 02

# Exercício 02

x <- seq(from = 3, to = 6, by = 0.1)
y <- exp(x) * cos(x)

Questão 03

# Exercício 3

# Letra A

i <- 10
for(i in 100){
  soma <- ((i^3) + (4 * i^2))
} 
print(soma)

# Letra B

i <- 10
for (i in 25) {
  soma <- ((2^i/i) + (3^i/i^2))
}
print(soma)
Questão 04

# Exercício 04

xVec <- sample(0:999, 250, replace = TRUE)
yVec <- sample(0:999, 250, replace = TRUE)

# Letra A

impar <- xVec %% 2 != 0
vet_4A <- xVec[impar]

# Letra B

vet_4B <- c( )

for(i in 2:250){
  
  vet_4B[i-1] <- yVec[i] - xVec[i-1]
  
}

# Letra C

vet_4C <- c( )

for(i in 2:250){
  
  vet_4C[i-1] <- sin(yVec[i]) / cos(xVec[i-1])
  
}



# Letra D

vet_4D <- c( )

for(i in 2:250){
  
  vet_4D[i-2] <- xVec[i-2] + 2 * xVec[i-1] - xVec[i]
  
}

# Letra E

soma <- 0

for(i in 1:249){
  
  soma <- soma + (exp(-1 * xVec[i+1]) / (xVec[i] + 10))
  
}

Questão 05

# Exercício 5

# Letra A

xVec <- sample(0:999, 250, replace = T)
yVec <- sample(0:999, 250, replace = T)

i <- 0
soma <- 0

for (i in yVec) {
  if(i > 600){
    soma <- soma + 1
  }
}

print(soma)

# Letra B

xVec <- sample(0:999, 250, replace = T)
yVec <- sample(0:999, 250, replace = T)

i <- 0
soma <- 0

for (i in xVec) {
  if(i > 600){
    print(i)
  }
}

# Letra C

xVec <- sample(0:999, 250, replace = T)
yVec <- sample(0:999, 250, replace = T)

i<- 0
valores <- c()

for(i in xVec){
    if( i > 600){
      valores[c] <- i

    }
  }

print(valores)

# Letra D

media <- mean(xVec)

vet_5D <- c( )

for(i in 1:250){
  
  vet_5D[i] = (abs(xVec[i] - media)) ** (1/2)
  
}

# Letra E

xVec <- sample(0:999, 250, replace = T)
yVec <- sample(0:999, 250, replace = T)

i<- 0
soma<-0

for(i in yVec){
  if ( i < 799){
    soma <- soma + 1
  }
}

print(soma)

# Letra F

xVec <- sample(0:999, 250, replace=T)
yVec <- sample(0:999, 250, replace=T)

i<- 0
soma <- 0

for (i in xVec) {
  if(i %% 2 == 0){
    soma <- soma + 1
  }
}

print(soma)

# Letra G

# Os vetores xVec e yVec não tem relação entre si
# Não compreendi muito bem o enunciado da questão

vet_5G <- xVec[order(xVec)]

# Letra H

posicoes <- seq(from = 1, to = 250, by = 3)

tamanho <- length(posicoes)

vet_5H <- c( )

for(i in 1:tamanho){
  
  vet_5H[i] <- yVec[posicoes[i]]
  
}

Questão 06

# Exercício 06

vet_6A <- c(2:39)
tamanho <- length(vet8)
vet_6B <- c( )

for(i in 2:tamanho){
  vet_6B[i-1] <- (vet_6A[i-1] / vet_6A[i])
}

vet_6C <- cumprod(vet_6B)
tamanho <- length(vet_6C)
soma <- 1 # A série começa em 1

for(i in 1:tamanho){
  soma <- soma + vet_6C[i]
}

Questão 07

# Exercício 07

# Letra A

library ( dslabs )
data ( murders )
str(murders)
murders[,4]
mean(murders[,4])
order(murders[,4]) #ordena pelo indice
mais_populoso <- murders[5,]
menos_populoso <- murders[51,]

# Letra B

library ( dslabs )
data ( murders )
murders <- cbind(murders, mortes_armas = (10000*murders$total)/murders$population)
print(murders)

# Letra C

library ( dslabs )
data ( murders )
murders_ordenado <- murders[order(murders$total),]
murders_ordenado$state

# Letra D

library ( dslabs )
data ( murders )
murders[which.max(murders$total),]
murders[which.min(murders$total),]

# Letra E

library ( dslabs )
data ( murders )
South <- murders[murders$region == "South", ]
West <- murders[murders$region == "West", ]
Northeast <- murders[murders$region == "Northeast", ]
North_Central <- murders[murders$region == "North Central", ]

South
West
Northeast
North_Central

mean(South[,5])
mean(West[,5])
mean(Northeast[,5])
mean(North_Central[,5])
media <- c(mean(South[,5]), mean(West[,5]), mean(Northeast[,5]), mean(North_Central[,5]))
sd(media)

min(media)
max(media)

# Letra F

library ( dslabs )
data ( murders )
boxplot(South$total)
boxplot(West$total)
boxplot(Northeast$total)
boxplot(North_Central$total)
