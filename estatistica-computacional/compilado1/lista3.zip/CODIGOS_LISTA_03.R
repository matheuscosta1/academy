# TERCEIRA LISTA DE EXERCICIOS
# ESTATISTICA COMPUTACIONAL (FAMAT31041)
# KEMUEL SANTOS PERES (11811BCC035)
# PEDRO HENRIQUE RESENDE RIBEIRO (12011BCC004)

# EXERCICIO 01

dado_01 <- sample(1:6, size = 100000, replace = TRUE)
dado_02 <- sample(1:6, size = 100000, replace = TRUE)

soma_dados <- dado_01 + dado_02

evento <- soma == 7 || soma == 11

probabilidade <- evento / 100000

resultado_exato <- 8 / 36


# EXERCICIO 02

urna_01 <- c("preta", "branca", "vermelha")
urna_02 <- c("preta", "branca", "vermelha")
urna_03 <- c("preta", "branca", "vermelha")

resultado <- c()

for(i in 1:100000){

    dado <- sample(1:6, size = 1)

    if(dado == 5){
        
        resultado[i] <- sample(urna_01, size = 1, prob = c(6/13, 3/13, 4/13))

    }else if(dado == 1 || dado == 4 || dado == 6){

        resultado[i] <- sample(urna_02, size = 1, prob = c(3/10, 5/10, 2/10))

    }else{

        resultado[i] <- sample(urna_03, size = 1, prob = c(4/8, 2/8, 2/8))

    }

}

evento <- resultado == "vermelha"

probabilidade <- evento / 100000 # Resposta = 0,234


# EXERCICIO 03

resultado <- c()

for(i in 1:100000){

    dado_01 <- sample(1:6, size = 1)
    dado_02 <- sample(1:6, size = 1)

    soma <- dado_01 + dado_02
    soma_inicial <- dado_01 + dado_02

    if(soma == 7 || soma == 1){

        contador <- 1

    }else if(soma == 2 || soma == 3 || soma == 12){

        contador <- 0

    }else{
        
        repeat{
            
            dado_01 <- sample(1:6, size = 1)
            dado_02 <- sample(1:6, size = 1)

            soma <- dado_01 + dado_02

            if(soma == 7){
                
                contador <- 0
                break

            }else if(soma == soma_inicial){

                contador <- 1
                break

            }

        }

    }

    resultado[i] <- contador

}

vitoria <- resutado == 1

probabilidade <- resultado / 100000


# EXERCICIO 04

bran <- c(0, 1, 0)
arya <- c(0, 0, 1)

moeda <- c(0, 1)

lancamentos <- sample(moeda, size = 3, replace = TRUE)

resultado <- c()

for(i in 1:100000){

    repeat{

        if(lancamentos == bran){

            cont <- 1
            break

        }else if(lancamentos == arya){

            cont <- 2
            break

        }else{
            
            lancamentos <- c(lancamentos, sample(moeda, size = 1))[2:4]

        }

    }

    resultado[i] = cont

}

prob_bran <- (resultado == 1) / 100000

prob_arya <- (resultado == 2) / 100000


# EXERCICIO 05

moeda <- c(0, 1)

resultado <- c()

posicao <- 0

j <- 0

for(i in 1:100000){
    
    repeat{

        lancamento <- sample(moeda, size = 1)

        if(lancamentos == 0){    

            posicao <- posicao + 1

        }else{

            posicao <- posicao - 1

        }

        j <- j + 1

        if(j == 4){ # 4, 6, 10 e 20 passos
            
            # 4 passos
            break

        }

    }

    if(posicao == 0){

        resultado[i] <- 1

    }else{

        resultado[i] <- 0

    }

}

probabilidade <- (resultado == 1) / 100000

# EXERCICIO 05 PROFESSOR

contador <- 0

for(i in 1:100000){

    # size é igual a quantidade de passos: 4, 6, 10 e 20
    passeio <- sample(c(-1, 1), size = 4, replace = TRUE)

    if(sum(passeio) == 0){

        contador <- contador + 1

    }

}

probabilidade <- contador / 100000


# EXERCICIO 06

# X ~ U[-1, 2]

x <- runif(100000, -1, 2)

funcao_fx <- (1 / sqrt(2 * pi)) * exp(-0.5 * x^2)

integral_01 <- (1 / 3) * mean(funcao_fx)

# Y ~ U[0, pi]

y <- runif(100000, 0, pi)

funcao_gy <- cos(y)

integral_02 <- (1 / pi) * mean(funcao_gy)


# EXERCICIO 07

probabilidade_2 <- function(n){
    
    resultado <- c()

    for(i in 1:n){

        u <- runif(1, 0, 1)

        if(u < 1/3){

            resultado[i] <- 1

        }else{

            resultado[i] <- 2

        }

    }

    prob_2 <- (resultado == 2) / n

    return(prob_2)

}

# Console:
# probabilidade_2(100)
# probabilidade_2(1000)
# probabilidade_2(10000)


# EXERCICIO 08

probabilidade_8 <- function(p, k){

    quantidades <- c()

    for(i in 1:100000){

        contador_01 <- 0
	contador_02 <- 0

        repeat{
	    
	    # Teste entre 0 e 1
            teste <- runif(1, 0, 1)

            if(teste < p){

                resultado[i] <- 1
                contador_01 <- contador_01 + 1

            }else{

                resultado[i] <- 0

            }

            contador_02 <- contador_02 + 1

            if(contador_01 == k){

                break

            }

        }

        quantidades[i] <- contador_02

    }
    
    prob_8 <- (quantidades > 8) / 100000

    return(prob_8)    

}

# Console:
# probabilidade_8(4/7, 3)


# EXERCICIO 09

probabilidade_07 <- function(n){

    valores <- c()

    for(i in 1:10000){

        y <- runif(1, 0, 1)

        Y <- (-1 + sqrt((8 * y) + 1)) / 2

        valores[i] <- Y

    }

    evento <- valores < 0.7

    prob_07 <- evento / 10000

    return(prob_07)

}

# X ~ U[0, 1]

x <- runif(10000, 0, 1)

funcao_fx <- (x^2 + x) / 2

# A integral equivale a esperança
integral_01 <- mean(funcao_fx)